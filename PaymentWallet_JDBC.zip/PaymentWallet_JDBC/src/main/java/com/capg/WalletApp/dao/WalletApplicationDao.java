package com.capg.WalletApp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.capg.WalletApp.bean.Customer;
import com.capg.WalletApp.util.DBUtil;

public class WalletApplicationDao implements IWalletApplicationDao {
	Connection con;
	public static ResultSet rs1;
	public static ResultSet rs2;
	public static ResultSet rs3;
	public static ResultSet rs4;
	float bal;
	public static String aadhar;
	public static long accNum;

	public int createAccount(Customer customer) throws Exception {

		int n1 = 0;
		int n2 = 0;
		try {
			con = DBUtil.getConnect();

			String insertQuery1 = "insert into customer1 values(?,?,?,?,?,?,?,?)";
			java.sql.PreparedStatement pstmt1 = con.prepareStatement(insertQuery1);

			System.out.println(customer.getFirstName());
			pstmt1.setString(1, customer.getFirstName());
			pstmt1.setLong(2, customer.getAadharNo());
			System.out.println(customer.getAadharNo());
			pstmt1.setString(3, customer.getContact());
			pstmt1.setString(4, customer.getGender());
			pstmt1.setString(5, customer.getEmail());
			pstmt1.setInt(6, customer.getAge());
			pstmt1.setString(7, customer.getUserName());
			pstmt1.setString(8, customer.getPassword());
			LocalDate date = LocalDate.now();
			String date1 = date.toString();
			String insertQuery2 = "insert into wallet1 values(?,?,?,?,?,?)";
			java.sql.PreparedStatement pstmt2 = con.prepareStatement(insertQuery2);

			pstmt2.setLong(1, customer.getWallet().getAccNo());
			pstmt2.setDouble(2, customer.getWallet().getAmount());
			pstmt2.setLong(3, customer.getWallet().getAadhar_no());
			pstmt2.setString(4, customer.getWallet().getBranch());
			pstmt2.setString(5, customer.getWallet().getAccount_type());
			pstmt2.setString(6, date1);
			// pstmt2.setDate(6, date1);

			n1 = pstmt1.executeUpdate();
			n2 = pstmt2.executeUpdate();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (n1 == 1 && n2 == 1) {
			return 1;
		}

		return 0;
	}

	public boolean login(String username, String password) throws Exception {
		try {
			con = DBUtil.getConnect();
			java.sql.Statement stmt1 = con.createStatement();
			String selectQuery1 = "select * from customer1 where USER_ID='" + username + "' and password ='" + password
					+ "'";
			// System.out.println(selectQuery1);
			rs1 = stmt1.executeQuery(selectQuery1);
			// System.out.println(rs1.next());
			if (rs1.next()) {

				aadhar = rs1.getString(2);
				System.out.println(aadhar);

				java.sql.Statement stmt2 = con.createStatement();
				String selectQuery2 = "select * from wallet1 where AADHAR_NO=" + aadhar;
				System.out.println(selectQuery2);
				rs2 = stmt2.executeQuery(selectQuery2);
				if (rs2.next()) {
					bal = rs2.getFloat(2);
				}
				return true;

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public float showBalance() {
		// try {
		// java.sql.Statement stmt2 = con.createStatement();
		// String selectQuery2 = "select * from wallet1 where AADHAR_NO="+aadhar;
		// rs2=stmt2.executeQuery(selectQuery2);
		//
		// //System.out.println("balance " +rs2.next());
		// if(rs2.next()) {
		// System.out.println("1");
		// bal = rs2.getFloat(2);
		// return bal;
		// }
		// } catch (SQLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		return bal;
	}

	public int deposit(float amount) {
		try {
			/* if(rs2.next()) { */

			// bal = rs2.getFloat(2) + amount;
			bal += amount;
			String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
			// System.out.println(updateQuery);
			java.sql.PreparedStatement stmt = con.prepareStatement(updateQuery);
			int r = stmt.executeUpdate();
			String selectQuery3 = "select * from wallet1 where AADHAR_NO=" + aadhar;
			java.sql.PreparedStatement stmt1 = con.prepareStatement(selectQuery3);

			// System.out.println(r);
			rs2 = stmt1.executeQuery();

			if (r == 1) {
				// System.out.println("Hii");
				String transaction = "Deposited " + Float.toString(amount);
				String insertQ = "insert into transaction2 values('" + aadhar + "','" + transaction + "')";
				// System.out.println(insertQ);
				java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
				stmt2.executeUpdate();
				return 1;
			}

			// }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	public int withdraw(float amount) {
		try {
			if (rs2.next()) {
				// System.out.println(1);
				bal -= amount;
				String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
				// System.out.println(updateQuery);
				String selectQuery3 = "select * from wallet1 where AADHAR_NO=" + aadhar;
				java.sql.PreparedStatement stmt = con.prepareStatement(updateQuery);
				int r = stmt.executeUpdate();
				// System.out.println(r);
				rs2 = stmt.executeQuery(selectQuery3);
				if (r == 1) {
					String transaction = "withdrawn " + Float.toString(amount);
					String insertQ = "insert into transaction2 values(" + aadhar + ",'" + transaction + "')";
					java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
					stmt2.executeUpdate();
					return 1;
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public int fundTransfer(int accNo, float amount) {
		float Currbal = 0;
		String qry = "select Initial_balance from wallet1 where Account_No=?";
		java.sql.PreparedStatement stmt;
		try {
			stmt = con.prepareStatement(qry);
			stmt.setInt(1, accNo);
			ResultSet resultSet = stmt.executeQuery();
			while (resultSet.next()) {
			 Currbal = resultSet.getFloat("initial_balance");
					
			}
			bal -= amount;
			String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
			// System.out.println(updateQuery);
			java.sql.PreparedStatement stmts = con.prepareStatement(updateQuery);
			stmts.executeUpdate();
			

			String updateQuery2 = "update wallet1 set INITIAL_BALANCE=INITIAL_BALANCE-? where Account_No=?";

			PreparedStatement pstat2 = con.prepareStatement(updateQuery2);
			pstat2.setInt(1, accNo);
			pstat2.setFloat(2, Currbal+amount);
			pstat2.executeUpdate();

			// String transfer = aadhar + " Amount of " + amount + " is transferred to " +
			// accNo;
			// transactionAdd(transfer);
			String transaction = aadhar + "Amount of " + amount + " is transferred to " + accNo;
			String insertQ = "insert into transaction2 values(" + aadhar + ",'" + transaction + "')";
			java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
			stmt2.executeUpdate();

		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return 0;

	}

	public void printTransaction() {
		try {
			String select = "select * from transaction2 where aadhar_No =" + aadhar;
			java.sql.PreparedStatement stmt = con.prepareStatement(select);
			rs4 = stmt.executeQuery();
			while (rs4.next()) {
				System.out.println(rs4.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
